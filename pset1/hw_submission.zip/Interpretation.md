# Overall Performance Analysis
In terms of average cumulative regret, it seems that Gittins and Greedy perform the best overall,
followed by Thompson, then ETC, the Epsilon Greedy and UCB, followed by Explore which performed the
worst. Of course, at the same time, it seems that as average cumulative regret decreases, the
variance increase (the order for average cumulative regret is inversed if we were to order by upper
bound of the 95% confidence interval). In general, it seems that the number of size and number of
runs is not effective to ompare yet the big-O efficiency of each of the algorithms. Specifically,
we know Explore and Greedy are both linear while, ETC/epsilon greedy both are sublinear T^(2/3). We
are still able to see thompson sampling and gittins index perform very well. AS noted in class,
thompson Sampling achieves excellent performance in practice.